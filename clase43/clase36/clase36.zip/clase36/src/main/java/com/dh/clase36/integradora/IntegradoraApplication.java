package com.dh.clase36.integradora;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegradoraApplication {

	public static void main(String[] args) {
		SpringApplication.run(IntegradoraApplication.class, args);
	}

}
