package com.dh.clase36.integradora.service;

import com.dh.clase23.integral.dao.IDao;
import com.dh.clase23.integral.dominio.Paciente;
import com.dh.clase36.integradora.entities.Paciente;
import com.dh.clase36.integradora.repository.PacienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PacienteService{
    @Autowired
    PacienteRepository repository;


    public List<Paciente> listarPacientes() {
        return repository.findAll();
    }

    @Override
    public Paciente buscarXEmail(String email) {
        return pacienteIDao.buscarEmail(email);
    }

    //clase 25
    @Override
    public Paciente guardar(Paciente paciente) {
        return pacienteIDao.guardar(paciente);
    }

    @Override
    public Paciente actualizar(Paciente paciente) {
        return pacienteIDao.actualizar(paciente);
    }

    @Override
    public Paciente buscar(Integer id) {
        return pacienteIDao.buscarId(id);
    }

    @Override
    public void eliminar(Integer id) {
        pacienteIDao.eliminar(id);
    }
}
